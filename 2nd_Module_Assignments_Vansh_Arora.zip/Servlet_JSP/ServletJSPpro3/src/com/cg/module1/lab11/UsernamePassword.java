package com.cg.module1.lab11;

import java.util.function.BiFunction;

public class UsernamePassword {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		BiFunction<String, String, Boolean> bi = (username,password)->username.equals("aks")&&password.equals("aks")?true:false;
		System.out.println(bi.apply("aks","aks"));
		
	}

}
