package com.cg.lab1jdbc.util;

import java.io.*;
import java.sql.*;
import java.util.*;

public class DBUtil {
       private static String url=null;
       private static String userName=null;
       private static String password=null;
       private static String driver=null;
       private static Connection conn=null;
       public static Connection getConn() throws SQLException, IOException{
    	   Properties myProps=getProps();
    	   url=myProps.getProperty("dburl");
    	   userName=myProps.getProperty("dbuserName");
    	   password=myProps.getProperty("dbpassword");
    	   if(conn==null) {
    		   conn=DriverManager.getConnection(url, userName, password);
    		   
    	   }
    	   return conn;
       }
       public static Properties getProps() throws IOException{
    	   Properties dbProps=new Properties();
    	   FileReader fileReader=new FileReader("Info.properties");
    	   dbProps.load(fileReader);
    	   return dbProps;
       }
}
