package com.cg.lab1jdbc.service;

public interface Service {
       public void insert();
       public void display();
       public void delete();
}
