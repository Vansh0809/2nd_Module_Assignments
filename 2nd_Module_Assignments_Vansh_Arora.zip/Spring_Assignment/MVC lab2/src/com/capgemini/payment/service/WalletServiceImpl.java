package com.capgemini.payment.service;
import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.capgemini.payment.beans.Customer;
import com.capgemini.payment.beans.Wallet;
import com.capgemini.payment.exception.InsufficientWalletBalanceException;
import com.capgemini.payment.exception.PhoneNumberAlreadyExist;
import com.capgemini.payment.exception.TransactionFailedException;
import com.capgemini.payment.exception.WalletAccountDoesNotExist;
import com.capgemini.payment.repo.WalletRepo;
@Service("ser")
@Component(value="ser")
public class WalletServiceImpl implements WalletService{
	
	@Autowired
	private WalletRepo repo;
	
	public WalletServiceImpl() {
		super();
	}

	public WalletServiceImpl(WalletRepo repo) {
		super();
		this.repo = repo;
	}



	public Customer createAccount(Customer customer) throws PhoneNumberAlreadyExist, TransactionFailedException {
		Customer cust = repo.findOne(customer.getMobileNo());
		if(cust!=null)
		{
			throw new PhoneNumberAlreadyExist("This Account Already Exist");
		}
		else
		{
			cust = repo.save(customer);
			if(cust!=null)
			{
				return cust; 
			}
			else
			{
				throw new TransactionFailedException("Backend Error Occured");
			}
		}
	}	
	 
	public Customer showBalance(String mobileNo) throws WalletAccountDoesNotExist  {
		
		Customer customer=repo.findOne(mobileNo);
		if(customer==null)
		{
			throw new WalletAccountDoesNotExist("No such wallet Exist");
		}
		else
			return customer;	
	}
	
	public Customer fundTransfer(String sourceMobileNo, String targetMobileNo, BigDecimal amount) throws InsufficientWalletBalanceException, WalletAccountDoesNotExist {

		Customer cust1=repo.findOne(sourceMobileNo);
		Customer cust2=repo.findOne(targetMobileNo);
		if(cust1!=null)
		{
			if(cust2!=null)
			{
				BigDecimal bal1 = cust1.getWallet().getBalance();
				BigDecimal bal2 = cust2.getWallet().getBalance();
				if(bal1.compareTo(amount)>=0)
				{
					bal1 = bal1.subtract(amount);
				cust1.setWallet(new Wallet(bal1));
				repo.save(cust1);
					bal2=bal2.add(amount);
				cust2.setWallet(new Wallet(bal2));
				repo.save(cust2);
				return cust1;
				}
				else
				{
					throw new InsufficientWalletBalanceException("Insufficient balance");				
				}
			}
			else
			{
				throw new WalletAccountDoesNotExist("recievers such wallet exist");
			}
		}
		else
		{
			throw new WalletAccountDoesNotExist("senders wallet exist");
		}
	}

	public Customer depositAmount(String mobileNo, BigDecimal amount) throws WalletAccountDoesNotExist{

		Customer cust=repo.findOne(mobileNo);
		if(cust==null)
		{
			throw new WalletAccountDoesNotExist("Wallet Account Doesnot Exist");
		}
		else
		{
			cust.getWallet().setBalance(cust.getWallet().getBalance().add(amount));
			return cust;	
		}
	}

	public Customer withdrawAmount(String mobileNo, BigDecimal amount) throws InsufficientWalletBalanceException, WalletAccountDoesNotExist{
		
		Customer cust=repo.findOne(mobileNo);
		if(cust.getMobileNo()==null)
			throw new WalletAccountDoesNotExist("Wallet Account Doesnot Exist");
		BigDecimal bal = cust.getWallet().getBalance();
		if(bal.compareTo(amount)>=0)
		{
			bal = bal.subtract(amount);
		cust.setWallet(new Wallet(bal));
		repo.save(cust);
		return cust;
		}
		else
		{
			throw new InsufficientWalletBalanceException("Insufficient Balance");	
		}
	}
}