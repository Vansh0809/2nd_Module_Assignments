package com.capgemini.payment.controllers;

import java.math.BigDecimal;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.payment.beans.Customer;
import com.capgemini.payment.beans.Wallet;
import com.capgemini.payment.exception.InsufficientWalletBalanceException;
import com.capgemini.payment.exception.PhoneNumberAlreadyExist;
import com.capgemini.payment.exception.TransactionFailedException;
import com.capgemini.payment.exception.WalletAccountDoesNotExist;
import com.capgemini.payment.service.WalletService;

@Controller
public class CustomerActionController {
	@Autowired	
	WalletService ser;
	
	@RequestMapping(value="/registerCustomer",method = RequestMethod.GET)
	public ModelAndView registerCustomer(HttpServletRequest request )
	{
		try 
		{
			Wallet wallet = new Wallet();
			wallet.setBalance(new BigDecimal(request.getParameter("balance")));
			Customer customer = new Customer();
			customer.setName(request.getParameter("name"));
			customer.setMobileNo(request.getParameter("mobileNo"));
			customer.setWallet(wallet);
			customer=ser.createAccount(customer);
			return new ModelAndView("welcomepage","customer",customer);
		} catch (PhoneNumberAlreadyExist e) {
			return new ModelAndView("error","customer",e.getMessage());
		} catch (TransactionFailedException e) {
			return new ModelAndView("error","customer",e.getMessage());
		}			
		
	}
	
	@RequestMapping(value="/showbal")
	public String getbalance()
	{
		return "showbalance";
	}
	
	@RequestMapping(value="/showBalance",method = RequestMethod.GET)
	public ModelAndView viewCustomer(@RequestParam("mobileNo") String mobileNo )
	{
		Customer customer;
		try {
			customer = ser.showBalance(mobileNo);
			return new ModelAndView("viewwallet","customer",customer);
		} catch (WalletAccountDoesNotExist e) {
			return new ModelAndView("error","customer",e.getMessage());
		}
		
	}
	
	@RequestMapping(value="/deposit")
	public String getdeposit()
	{
		return "deposit";
	}
	
	@RequestMapping(value="/deposit_amount", method = RequestMethod.GET)
	public ModelAndView deposit(HttpServletRequest request)
	{
		Customer customer = null;
		String mobileNo=request.getParameter("mobileNo");
		String balance=request.getParameter("balance");
		try {
			customer=ser.depositAmount(mobileNo, new BigDecimal(balance));
			return new ModelAndView("depositsucess","customer",customer);	
		} catch (WalletAccountDoesNotExist e) {
			return new ModelAndView("error","customer",e.getMessage());
		}
	}
	
	@RequestMapping(value="/withdraw")
	public String getwithdraw()
	{
		return "withdraw";		
	}
	
	@RequestMapping(value="/withdraw_amount", method = RequestMethod.GET)
	public ModelAndView withdraw(HttpServletRequest request)
	{
		Customer customer = null;
		String mob=request.getParameter("mobileNo");
		String bal=request.getParameter("balance");
		try {
			customer=ser.withdrawAmount(mob, new BigDecimal(bal));
			return new ModelAndView("withdrawsucess","customer",customer);
		} catch (InsufficientWalletBalanceException e) {
			return new ModelAndView("error","customer",e.getMessage());
		} catch (WalletAccountDoesNotExist e) {
			return new ModelAndView("error","customer",e.getMessage());
		}			
	}
	
	@RequestMapping(value="/fundtransfer")
	public String Funds()
	{
		return "fundtransfer";
	}
	
	@RequestMapping(value="/fundtransfered", method = RequestMethod.GET)
	public ModelAndView fundTransfer(HttpServletRequest request)
	{
		Customer customer = null;
		String source=request.getParameter("sourceMobileNo");
		String target=request.getParameter("destinationMobileNo");
		String amount=request.getParameter("balance");
		
			try {
				customer=ser.fundTransfer(source, target, new BigDecimal(amount));
				return new ModelAndView("fundstransfered","customer",customer);	
			} catch (InsufficientWalletBalanceException e) {
				return new ModelAndView("error","customer",e.getMessage());
			} catch (WalletAccountDoesNotExist e) {
				return new ModelAndView("error","customer",e.getMessage());
			}
	}	
}