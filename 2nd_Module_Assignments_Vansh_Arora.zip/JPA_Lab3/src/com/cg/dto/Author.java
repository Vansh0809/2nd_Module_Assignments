package com.cg.dto;

import java.util.*;
import javax.persistence.*;

@Entity
@Table(name="author_masters")
public class Author {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="author_id", length=10)
	private int id;
	
	@Column(name="author_name", length=30)
	private String name;
	
	@ManyToMany(mappedBy="auth")
	Set<Book> b=new HashSet<Book>();

	
	
	public Author() {
		super();
		
	}

	
	
	public Author(int id, String name, Set<Book> b) {
		super();
		this.id = id;
		this.name = name;
		this.b = b;
	}

	
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Set<Book> getB() {
		return b;
	}

	public void setB(Set<Book> b) {
		this.b = b;
	}

	
	
	@Override
	public String toString() {
		return "Author [id=" + id + ", name=" + name + ", b=" + b + "]";
	}

}
