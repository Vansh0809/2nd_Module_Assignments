package com.cg.dto;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.*;

@Entity
@Table(name="book_masters")
public class Book {
	
	@Id
	@Column(name="book_isbn", length=10)
	private int ISBN;
	
	@Column(name="book_title", length=20)
	private String title;
	
	@Column(name="book_price", length=5)
	private float price;
	
	@ManyToMany(cascade=CascadeType.ALL)
	@JoinTable(name="auth_book",joinColumns= {@JoinColumn(name="book_masters")},inverseJoinColumns={@JoinColumn(name="author_masters")})
	
	
	Set<Author> auth= new HashSet<Author>();
	
	

	public Book() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Book(int iSBN, String title, float price, Set<Author> auth) {
		super();
		ISBN = iSBN;
		this.title = title;
		this.price = price;
		this.auth = auth;
	}

	public int getISBN() {
		return ISBN;
	}

	public void setISBN(int iSBN) {
		ISBN = iSBN;
	}

	public String getTitle() {
		return title;
	}

	@Override
	public String toString() {
		return "Book [ISBN=" + ISBN + ", title=" + title + ", price=" + price + ", auth=" + auth + "]";
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public Set<Author> getAuth() {
		return auth;
	}

	public void setAuth(Set<Author> auth) {
		this.auth = auth;
	}
	
	
	
	
	
	
	
}
