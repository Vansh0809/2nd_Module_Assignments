package com.cg.ui;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.*;

import com.cg.Util.JPAUtil;
import com.cg.dto.Author;
import com.cg.dto.Book;

public class View {

	public static void main(String[] args) {
		 EntityManager em=JPAUtil.getEntityManager();
		    EntityTransaction et=em.getTransaction();

		    Author a1= new Author();
		    a1.setName("Vansh");
		    
		    Author a2= new Author();
		    a2.setName("Arora");
		    
		    Author a3= new Author();
		    a3.setName("VA");
		    
		    Set<Author> eet= new HashSet<Author>();
		    eet.add(a1);
		    eet.add(a2);
		    eet.add(a3);
		    
		    Book bk=new Book();
		    bk.setISBN(4535);
		    bk.setPrice(100.0f);
		    bk.setTitle("fgth");
		    bk.setAuth(eet);
		    
		    Book bk1=new Book();
		    bk1.setISBN(455);
		    bk1.setPrice(2300.0f);
		    bk1.setTitle("fghfs");
		    bk1.setAuth(eet);
		    
		    Set<Book> ek=new HashSet<Book>();
		    ek.add(bk);
		   ek.add(bk1);
		   
		   et.begin();
		   em.persist(bk);
		   em.persist(bk1);
		   et.commit();
		   
		   System.out.println("data is persisted");
		    
	}

}
