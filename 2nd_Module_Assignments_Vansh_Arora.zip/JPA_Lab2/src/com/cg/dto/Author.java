package com.cg.dto;

import javax.persistence.*;

@Entity
@Table(name="Author")
public class Author {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="author_id", length=10)
	private int authorId;

	@Column(name="first_name",length=20)
	private String firstName;
	
	@Column(name="middle_name",length=20)
	private String midddleName;
	
	@Column(name="last_name",length=20)
	private String LastName;
	
	@Column(name="phone_no",length=13)
	private String phoneNo;
	
	
	
	public Author(int authorId, String firstName, String midddleName, String lastName, String phoneNo) {
		super();
		this.authorId = authorId;
		this.firstName = firstName;
		this.midddleName = midddleName;
		LastName = lastName;
		this.phoneNo = phoneNo;
	}
	
	
	public Author() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	public int getAuthorId() {
		return authorId;
	}
	public void setAuthorId(int authorId) {
		this.authorId = authorId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getMidddleName() {
		return midddleName;
	}
	public void setMidddleName(String midddleName) {
		this.midddleName = midddleName;
	}
	public String getLastName() {
		return LastName;
	}
	public void setLastName(String lastName) {
		LastName = lastName;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	
	
	@Override
	public String toString() {
		return "Author [authorId=" + authorId + ", firstName=" + firstName + ", midddleName=" + midddleName
				+ ", LastName=" + LastName + ", phoneNo=" + phoneNo + "]";
	}
	
	
	
	
	
	
}
