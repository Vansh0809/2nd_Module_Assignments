package com.cg.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import com.cg.Util.JPAUtil;
import com.cg.dto.Author;


public class AuthorDaoImpl implements AuthorDao{
	
	EntityManager em=null;
    EntityTransaction et=null;
    

	public AuthorDaoImpl() {
		em=JPAUtil.getEntityManager();
		et=em.getTransaction();
	}

	
	@Override
	public Author addAuthor(Author author) {
		et.begin();
		em.persist(author);
		et.commit();
		return author;
	}

	
	@Override
	public Author deleteAuthor(int authorId) {
		Author author=em.find(Author.class, authorId);
		et.begin();
		em.remove(authorId);
		et.commit();
		return author;
	}

	@Override
	public Author displayAuthor(int authorId) {
		Author author=em.find(Author.class, authorId);
		return author;
	}

	@Override
	public Author updateAuthor(int authorId, String newFirstName, String newMiddleName, String newLastName,
			String newPhoneNo) {
		Author author=em.find(Author.class, authorId);
		author.setFirstName(newFirstName);
		author.setMidddleName(newMiddleName);
		author.setLastName(newLastName);
		author.setPhoneNo(newPhoneNo);
		et.begin();
		em.merge(author);
		et.commit();
		return author;
	}

}
