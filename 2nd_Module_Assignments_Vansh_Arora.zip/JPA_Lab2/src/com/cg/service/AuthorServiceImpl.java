package com.cg.service;

import com.cg.dao.AuthorDao;
import com.cg.dao.AuthorDaoImpl;
import com.cg.dto.Author;

public class AuthorServiceImpl implements AuthorService{
	
	AuthorDao authorDao=null;
	public AuthorServiceImpl() {
		authorDao=new AuthorDaoImpl();
	}

	@Override
	public Author addAuthor(Author author) {
		
		return authorDao.addAuthor(author);
	}

	@Override
	public Author deleteAuthor(int authorId) {
		
		return authorDao.deleteAuthor(authorId);
	}

	@Override
	public Author displayAuthor(int authorId) {
		
		return authorDao.displayAuthor(authorId);
	}

	@Override
	public Author updateAuthor(int authorId, String newFirstName, String newMiddleName, String newLastName,
			String newPhoneNo) {
		
		return authorDao.updateAuthor(authorId, newFirstName, newMiddleName, newLastName, newPhoneNo);
	}

}
